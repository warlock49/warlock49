function totalIt() {
  var input = document.getElementsByName("product");
  var total = 0;
  for (var i = 0;
     i < input.length; i++) 
     {

    if (input[i].checked) {

      total += parseFloat(input[i].value);

    }

  }
  document.getElementById("total").value = "Rs." + total.toFixed(2);
}

function total() {
  var input = document.getElementsByName("product");
  var totalSun = 0;
  var prodName = "";
  for (var i = 0; i < input.length; i++) 
  {
    if (input[i].checked) {
      totalSun += parseFloat(input[i].value);
      prodName += input[i].id + " " + parseFloat(input[i].value) + "  ";

    }

  }
  document.getElementById("showR").value =
    prodName + "Total Cost =" + totalSun.toFixed(2);
}
